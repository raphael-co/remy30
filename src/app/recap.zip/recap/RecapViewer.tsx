"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./recap.module.css";

type Product = {
  title?: string | null;
  subtitle?: string | null;
  description?: string | null;
  heroImageUrl?: string | null;
  gallery?: string[] | null;
};

type Review = {
  id: string;
  name?: string | null;
  rating?: number | null;
  message?: string | null;
  imageUrl?: string | null;
  createdAt?: string | null;
};

function uniqStrings(xs: string[]) {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const x of xs) {
    const v = (x || "").trim();
    if (!v) continue;
    if (seen.has(v)) continue;
    seen.add(v);
    out.push(v);
  }
  return out;
}

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function stars(rating: number) {
  const r = clamp(Math.round(rating || 0), 0, 5);
  return "★★★★★".slice(0, r) + "☆☆☆☆☆".slice(0, 5 - r);
}

export default function RecapViewer() {
  const router = useRouter();

  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  const [i, setI] = useState(0);

  // lock scroll + safe fullscreen
  useEffect(() => {
    const prev = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden";
    return () => {
      document.documentElement.style.overflow = prev;
    };
  }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [p, r] = await Promise.all([
          fetch("/api/product", { cache: "no-store" }).then((x) => x.json()),
          fetch("/api/reviews", { cache: "no-store" }).then((x) => x.json()),
        ]);
        if (!alive) return;
        setProduct(p || null);
        setReviews(Array.isArray(r) ? r : []);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const slides = useMemo(() => {
    const title = product?.title || "Récap";
    const subtitle = product?.subtitle || "Moments capturés";
    const hero = product?.heroImageUrl || null;

    const gallery = uniqStrings([...(product?.gallery || []), ...(reviews.map((x) => x.imageUrl || "").filter(Boolean) as string[])]);
    const latest = [...reviews].sort((a, b) => {
      const da = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const db = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return db - da;
    });

    const s: Array<
      | { type: "intro"; bg?: string | null; title: string; subtitle: string }
      | { type: "stats"; bg?: string | null; items: { label: string; value: string }[] }
      | { type: "photos"; bg?: string | null; photos: string[] }
      | { type: "reviews"; bg?: string | null; top: Review[] }
      | { type: "outro"; bg?: string | null; title: string; subtitle: string }
    > = [];

    s.push({ type: "intro", bg: hero, title, subtitle });

    s.push({
      type: "stats",
      bg: hero,
      items: [
        { label: "Photos", value: String(gallery.length) },
        { label: "Commentaires", value: String(reviews.length) },
        { label: "Note moyenne", value: reviews.length ? (reviews.reduce((acc, x) => acc + (x.rating || 0), 0) / reviews.length).toFixed(1) : "—" },
      ],
    });

    if (gallery.length) s.push({ type: "photos", bg: hero, photos: gallery.slice(0, 30) });

    s.push({ type: "reviews", bg: hero, top: latest.slice(0, 3) });

    s.push({ type: "outro", bg: hero, title: "À bientôt ✨", subtitle: "Merci d’avoir participé !" });

    return s;
  }, [product, reviews]);

  useEffect(() => {
    setI((v) => clamp(v, 0, Math.max(0, slides.length - 1)));
  }, [slides.length]);

  const go = (dir: -1 | 1) => {
    setI((v) => clamp(v + dir, 0, slides.length - 1));
  };

  // basic swipe
  const startX = useRef<number | null>(null);
  const startY = useRef<number | null>(null);

  const onTouchStart = (e: React.TouchEvent) => {
    const t = e.touches[0];
    startX.current = t.clientX;
    startY.current = t.clientY;
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    if (startX.current == null || startY.current == null) return;
    const t = e.changedTouches[0];
    const dx = t.clientX - startX.current;
    const dy = t.clientY - startY.current;

    startX.current = null;
    startY.current = null;

    // ignore vertical scroll intent
    if (Math.abs(dy) > Math.abs(dx)) return;
    if (Math.abs(dx) < 40) return;

    if (dx < 0) go(1);
    else go(-1);
  };

  const slide = slides[i];

  return (
    <div className={styles.wrap} onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
      <div className={styles.topbar}>
        <button className={styles.close} onClick={() => router.back()} aria-label="Fermer">
          ✕
        </button>

        <div className={styles.dots} aria-hidden="true">
          {slides.map((_, idx) => (
            <span key={idx} className={idx === i ? styles.dotOn : styles.dot} />
          ))}
        </div>
      </div>

      <div className={styles.stage}>
        {loading || !slide ? (
          <div className={styles.loading}>Chargement…</div>
        ) : (
          <Slide slide={slide} />
        )}
      </div>

      <div className={styles.bottom}>
        <button className={styles.navBtn} onClick={() => go(-1)} disabled={i === 0} aria-label="Précédent">
          ‹
        </button>

        <div className={styles.progress}>
          <div className={styles.progressBar} style={{ width: slides.length ? `${((i + 1) / slides.length) * 100}%` : "0%" }} />
        </div>

        <button className={styles.navBtn} onClick={() => go(1)} disabled={i === slides.length - 1} aria-label="Suivant">
          ›
        </button>
      </div>
    </div>
  );
}

function Slide({ slide }: { slide: any }) {
  const bg = slide.bg ? `url(${slide.bg})` : "none";

  if (slide.type === "intro") {
    return (
      <div className={styles.slide} style={{ backgroundImage: bg }}>
        <div className={styles.vignette} />
        <div className={styles.content}>
          <div className={styles.kicker}>Récap</div>
          <h1 className={styles.h1}>{slide.title}</h1>
          <p className={styles.p}>{slide.subtitle}</p>
          <div className={styles.hint}>Swipe →</div>
        </div>
      </div>
    );
  }

  if (slide.type === "stats") {
    return (
      <div className={styles.slide} style={{ backgroundImage: bg }}>
        <div className={styles.vignette} />
        <div className={styles.content}>
          <div className={styles.kicker}>Stats</div>
          <div className={styles.grid}>
            {slide.items.map((it: any) => (
              <div key={it.label} className={styles.card}>
                <div className={styles.cardVal}>{it.value}</div>
                <div className={styles.cardLab}>{it.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (slide.type === "photos") {
    return (
      <div className={styles.slide} style={{ backgroundImage: bg }}>
        <div className={styles.vignette} />
        <div className={styles.content}>
          <div className={styles.kicker}>Galerie</div>
          <div className={styles.masonry}>
            {slide.photos.slice(0, 12).map((src: string) => (
              <div key={src} className={styles.ph}>
                {/* next/image optional; ici img simple pour éviter config domains */}
                <img src={src} alt="" className={styles.img} loading="lazy" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (slide.type === "reviews") {
    return (
      <div className={styles.slide} style={{ backgroundImage: bg }}>
        <div className={styles.vignette} />
        <div className={styles.content}>
          <div className={styles.kicker}>Avis</div>
          {slide.top?.length ? (
            <div className={styles.reviews}>
              {slide.top.map((r: any) => (
                <div key={r.id} className={styles.rCard}>
                  <div className={styles.rTop}>
                    <div className={styles.avatar}>{(r.name || "?").slice(0, 1).toUpperCase()}</div>
                    <div className={styles.rMeta}>
                      <div className={styles.rName}>{r.name || "Anonyme"}</div>
                      <div className={styles.rStars}>{stars(r.rating || 0)}</div>
                    </div>
                  </div>
                  {r.message ? <div className={styles.rMsg}>{r.message}</div> : <div className={styles.rMsgMuted}>—</div>}
                </div>
              ))}
            </div>
          ) : (
            <div className={styles.empty}>Pas encore d’avis.</div>
          )}
        </div>
      </div>
    );
  }

  if (slide.type === "outro") {
    return (
      <div className={styles.slide} style={{ backgroundImage: bg }}>
        <div className={styles.vignette} />
        <div className={styles.content}>
          <div className={styles.kicker}>Fin</div>
          <h2 className={styles.h2}>{slide.title}</h2>
          <p className={styles.p}>{slide.subtitle}</p>
        </div>
      </div>
    );
  }

  return null;
}
