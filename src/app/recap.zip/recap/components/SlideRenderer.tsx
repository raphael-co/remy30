"use client";

import React from "react";
import type { RecapSlide } from "../types";
import IntroSlide from "./slides/IntroSlide";
import StatsSlide from "./slides/StatsSlide";
import GallerySlide from "./slides/GallerySlide";
import ReviewsSlide from "./slides/ReviewsSlide";
import OutroSlide from "./slides/OutroSlide";

export default function SlideRenderer({ slide }: { slide: RecapSlide }) {
  switch (slide.type) {
    case "intro":
      return <IntroSlide slide={slide} />;
    case "stats":
      return <StatsSlide slide={slide} />;
    case "photos":
      return <GallerySlide slide={slide} />;
    case "reviews":
      return <ReviewsSlide slide={slide} />;
    case "outro":
      return <OutroSlide slide={slide} />;
    default:
      return null;
  }
}
