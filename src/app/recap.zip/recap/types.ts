export type Product = {
  title?: string | null;
  subtitle?: string | null;
  description?: string | null;
  heroImageUrl?: string | null;
  gallery?: string[] | null;
};

export type Review = {
  id: string;
  name?: string | null;
  rating?: number | null;
  message?: string | null;
  imageUrl?: string | null;
  createdAt?: string | null;
};

export type RecapSlide =
  | { type: "intro"; bg?: string | null; title: string; subtitle: string }
  | { type: "stats"; bg?: string | null; items: { label: string; value: string }[] }
  | { type: "photos"; bg?: string | null; photos: string[] }
  | { type: "reviews"; bg?: string | null; top: Review[] }
  | { type: "outro"; bg?: string | null; title: string; subtitle: string };
