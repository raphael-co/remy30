"use client";

import { useEffect, useMemo, useState } from "react";
import type { Product, Review, RecapSlide } from "../types";
import { uniqStrings } from "../utils";

export function useRecapData() {
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        const [p, r] = await Promise.all([
          fetch("/api/product", { cache: "no-store" }).then((x) => x.json()),
          fetch("/api/reviews", { cache: "no-store" }).then((x) => x.json()),
        ]);

        if (!alive) return;
        setProduct(p || null);
        setReviews(Array.isArray(r) ? r : []);
      } finally {
        if (alive) setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, []);

  const slides: RecapSlide[] = useMemo(() => {
    const title = product?.title || "Récap";
    const subtitle = product?.subtitle || "Moments capturés";
    const hero = product?.heroImageUrl || null;

    const gallery = uniqStrings([
      ...(product?.gallery || []),
      ...(reviews.map((x) => x.imageUrl || "").filter(Boolean) as string[]),
    ]);

    const latest = [...reviews].sort((a, b) => {
      const da = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const db = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return db - da;
    });

    const s: RecapSlide[] = [];

    s.push({ type: "intro", bg: hero, title, subtitle });

    s.push({
      type: "stats",
      bg: hero,
      items: [
        { label: "Photos", value: String(gallery.length) },
        { label: "Commentaires", value: String(reviews.length) },
        {
          label: "Note moyenne",
          value: reviews.length
            ? (reviews.reduce((acc, x) => acc + (x.rating || 0), 0) / reviews.length).toFixed(1)
            : "—",
        },
      ],
    });

    if (gallery.length) s.push({ type: "photos", bg: hero, photos: gallery.slice(0, 30) });

    s.push({ type: "reviews", bg: hero, top: latest.slice(0, 3) });

    s.push({ type: "outro", bg: hero, title: "À bientôt ✨", subtitle: "Merci d’avoir participé !" });

    return s;
  }, [product, reviews]);

  return { loading, product, reviews, slides };
}
