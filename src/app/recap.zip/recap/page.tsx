export const dynamic = "force-dynamic";

import RecapViewer from "./RecapViewer";

export default function RecapPage() {
  return <RecapViewer />;
}
